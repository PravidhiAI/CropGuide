Write-Host "==========================================================" -ForegroundColor Green
Write-Host " TERRAFORM — Starting FastAPI Agricultural Backend Server" -ForegroundColor Cyan
Write-Host " Scenario: High-Altitude Cold Terrace Decision Support" -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Green

# Ensure working directory is the repository root
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

# Check Python installation
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "Error: Python is not found in PATH. Please install Python 3.10+." -ForegroundColor Red
    pause
    exit 1
}

# Install / verify requirements
Write-Host "Checking backend dependencies..." -ForegroundColor Yellow
python -m pip install -r backend/requirements.txt --quiet

# Launch Uvicorn
Write-Host "`nStarting Uvicorn server on http://127.0.0.1:8000 ..." -ForegroundColor Green
Write-Host "API Documentation available at: http://127.0.0.1:8000/docs" -ForegroundColor Cyan
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
