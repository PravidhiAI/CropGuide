# TERRAFORM — AI-Powered Agricultural Intelligence System
### Decision-Support Engine for High-Altitude Cold Terrace Agriculture

---

## 🏔️ Assigned Land Scenario: High-Altitude Cold Terrace
Mountain agricultural terraces in high-altitude zones (1400m – 3800m) present harsh environmental constraints:
- **Nocturnal radiation frost** that freezes cellular tissue in tender foliage.
- **Steep terrace slopes** prone to riser collapse and sheet erosion during sudden cloudbursts.
- **Short thermal growing windows** cut off by early autumn snowfalls.
- **Rocky, shallow soil shelves** that impede deep root penetration.
- **Glacial or cold meltwater** that induces root temperature shock if applied unwarmed.

**TERRAFORM** is an intelligent, explainable decision-support web application that guides anyone—even someone with zero farming experience—from entering simple, tactile, non-laboratory field observations to selecting optimal crops, constructing contour beds, executing 9-stage sequential cultivation, managing pests via biological IPM, assessing harvest readiness, and curing produce for long-term winter cellar storage.

---

## 🏗️ Architecture & Technology Stack

| Layer | Technologies | Role |
|---|---|---|
| **Frontend** | React 19, Vite, TypeScript, Lucide Icons, Vanilla CSS | 16 responsive views, interactive checklists, progress tracking, live differential reasoning, and raw JSON inspection. |
| **Backend** | Python 3.10+, FastAPI, Pydantic v2, Uvicorn | Deterministic recommendation engine, land analysis engine, 9-stage plan generator, IPM diagnostic assistant. |
| **Persistence** | SQLite, SQLAlchemy | Local disk persistence for land assessments, active cultivation plans, task completion checklists, and field journal logs. |
| **Knowledge Base** | Structured JSON (`data/`) | 12 verified cold-terrace candidate crops, 9 pest/disease profiles, 5 terrace engineering methods, and apex institutional source citations. |
| **Scientific Sources** | ICAR-CPRI, ICAR-VPKAS, ICAR-IARI Katrain, ICAR-IIWBR, SKUAST-K, UHF Solan | Peer-reviewed packages of practices from apex Indian mountain research institutes. |

---

## 📁 Repository Directory Structure

```text
TERRAFORM/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── __init__.py
│   │   │   └── endpoints.py          # REST endpoints (/api/v1/...)
│   │   ├── database/
│   │   │   ├── __init__.py
│   │   │   ├── db.py                 # SQLite engine & session
│   │   │   └── models.py             # SQLAlchemy models
│   │   ├── engine/
│   │   │   ├── __init__.py
│   │   │   ├── land_analysis.py      # Non-lab observation evaluator
│   │   │   ├── recommendation.py     # Hard exclusions & suitability scoring
│   │   │   ├── cultivation_planner.py# 9-stage sequential plan generator
│   │   │   ├── pest_engine.py        # Multi-symptom IPM diagnostic engine
│   │   │   └── harvest_engine.py     # Morphological maturity & storage evaluator
│   │   ├── knowledge_base/
│   │   │   ├── __init__.py
│   │   │   └── loader.py             # Knowledge base loader & cache
│   │   ├── schemas/
│   │   │   ├── __init__.py
│   │   │   ├── common.py             # Standard JSON envelope
│   │   │   ├── land_assessment.py    # Input / output schemas
│   │   │   ├── crop.py               # Recommendation schemas
│   │   │   ├── cultivation.py        # Journey & journal schemas
│   │   │   └── pest.py               # Diagnosis & harvest schemas
│   │   ├── __init__.py
│   │   └── main.py                   # FastAPI application entrypoint
│   ├── tests/
│   │   ├── __init__.py
│   │   ├── test_api.py               # REST API integration tests
│   │   ├── test_engine.py            # Conflict & unit tests
│   │   └── test_scenarios.py         # 7 required mountain scenario tests
│   ├── requirements.txt              # Python dependencies
│   └── .env.example
├── data/
│   ├── crop_database.json            # 12 verified high-altitude crops
│   ├── pest_database.json            # 9 mountain pests, diseases & stresses
│   ├── cultivation_methods.json      # Terrace bunding, raised beds, cloches
│   └── source_registry.json          # ICAR / KVK research publications
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.tsx            # Sidebar navigation & status indicators
│   │   │   ├── JSONInspectorModal.tsx# Live raw API exchange inspector
│   │   │   └── CropDetailModal.tsx   # Verified botanical specifications modal
│   │   ├── pages/
│   │   │   ├── WelcomeDashboard.tsx  # Scenario introduction & quick actions
│   │   │   ├── LandAssessmentWizard.tsx # 4-step non-lab observation wizard
│   │   │   ├── LandAnalysisView.tsx  # Facts vs inferences, terrace risks
│   │   │   ├── CropRecommendationsView.tsx # Ranked crops & hard exclusions panel
│   │   │   ├── CropComparisonView.tsx# Head-to-head crop comparison
│   │   │   ├── CultivationPlanView.tsx # 9-stage plan with persistent tasks
│   │   │   ├── OngoingCareChecklistView.tsx # Daily & weekly task tracker
│   │   │   ├── PestAssistantView.tsx # Interactive IPM diagnostic assistant
│   │   │   ├── HarvestReadinessView.tsx # Maturity verification & delay risks
│   │   │   ├── HarvestStorageGuideView.tsx # Reaping, curing & root cellar specs
│   │   │   ├── FieldJournalView.tsx  # Observation logs & harvest yield records
│   │   │   ├── CultivationCalendarView.tsx # 9-stage Gantt lifecycle timeline
│   │   │   ├── LiveChallengeView.tsx # Dedicated judging reasoning engine
│   │   │   ├── JSONInspectorView.tsx # Full API telemetry inspector
│   │   │   └── SettingsExportView.tsx# Data export & audio controls
│   │   ├── services/
│   │   │   └── api.ts                # REST client & telemetry recorder
│   │   ├── types/
│   │   │   └── index.ts              # TypeScript interfaces
│   │   ├── utils/
│   │   │   └── audio.ts              # Web Audio API sound synthesizer
│   │   ├── App.tsx                   # Master state coordinator
│   │   ├── index.css                 # Vanilla CSS design tokens & themes
│   │   └── main.tsx
│   ├── package.json
│   ├── vite.config.ts
│   └── .env.example
├── API_EXAMPLES.md                   # Real JSON requests and responses
├── run_backend.bat                   # Windows batch backend launcher
├── run_backend.ps1                   # Windows PowerShell backend launcher
├── run_frontend.bat                  # Windows batch frontend launcher
├── run_frontend.ps1                  # Windows PowerShell frontend launcher
├── run_all.bat                       # Unified batch launcher (both services)
├── run_all.ps1                       # Unified PowerShell launcher
├── README.md
└── .gitignore
```

---

## ⚡ Quick Start on Windows & Visual Studio Code

### 1. Prerequisites
- **Python 3.10+** (verified on Python 3.14)
- **Node.js 18+** (verified on Node v24.21.0, npm 11.19.0)
- **Visual Studio Code** on Windows

---

### 2. One-Click Unified Launch
Open PowerShell or Command Prompt in the project folder and run:
```powershell
# Using PowerShell
.\run_all.ps1

# Or using Command Prompt
run_all.bat
```
This automatically starts:
1. **FastAPI Backend** on `http://127.0.0.1:8000`
2. **Vite React Frontend** on `http://localhost:5173`
3. Automatically opens your default web browser to the dashboard.

---

### 3. Manual Step-by-Step Setup

#### A. Backend Setup
1. Open a terminal in the project directory:
   ```powershell
   # Install dependencies
   python -m pip install -r backend/requirements.txt
   ```
2. Start the FastAPI server:
   ```powershell
   python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
   ```
3. Verify backend health in browser or terminal:
   - Health check: [http://127.0.0.1:8000/api/v1/health](http://127.0.0.1:8000/api/v1/health)
   - Interactive Swagger API docs: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)

#### B. Frontend Setup
1. Open a second terminal window in `frontend/`:
   ```powershell
   cd frontend
   npm install
   npm run dev -- --host 127.0.0.1 --port 5173
   ```
2. Open your web browser at:
   - [http://localhost:5173](http://localhost:5173)

---

## 🧪 Running Automated Tests

All 23 backend automated tests evaluate:
- System health and knowledge base integrity
- Observation conflict detection
- Missing information penalties
- Hard exclusion rules (frost vs buckwheat, waterlogging vs barley/carrot/potato, rocky soil vs carrots)
- All 7 mandated cold terrace test scenarios
- 9-stage sequential plan generation
- Persistent task checklists and journal logging

Run the test suite from the repository root:
```powershell
python -m pytest backend/tests -v
```

**Expected output:**
```text
======================== 23 passed in 1.23s ========================
```

---

## ⚖️ Hackathon Judging Guide: Live Challenge Mode

Judges can evaluate the system's reasoning over **completely unseen combinations of inputs** without predetermined hardcoded recommendations:

1. Click **"Live Challenge Mode"** in the sidebar (highlighted with a gold "JUDGE" badge).
2. Choose one of the 5 quick demonstration presets or enter custom parameters:
   - **Preset 1 (Cold Sunny + Water):** Crumbly loam, gentle slope, reliable irrigation -> Recommends Hill Potato, Garden Pea, Snowball Cauliflower.
   - **Preset 2 (High Frost Alert):** Night freezing expected -> **Buckwheat is immediately excluded** (`Hard Frost Lethality: foliage dies at -0.5°C`), while Turnip and Spinach rank top.
   - **Preset 3 (Waterlogged Bog):** Pools on surface, sticky clay -> **Potato, Barley, and Carrot are excluded** (`Root Hypoxia & Immediate Tuber Rot`), while raised beds are recommended.
   - **Preset 4 (Rocky Shelf):** Rocky shallow soil -> **Carrot is excluded** (`Physical Root Impedance: taproots fork/deform`), while shallow-rooting Turnips and greens remain viable.
   - **Preset 5 (Deep Shaded North Face):** Mostly shaded -> **Barley and Buckwheat are excluded** (`Insufficient Photosynthetic Irradiance`), while shade-hardy Spinach is favored.
3. Click **"Evaluate Live Challenge"**:
   - The system calls `POST /api/v1/live-challenge/evaluate`.
   - The **"Differential Reasoning: What Changed and Why"** panel explains every single parameter alteration and why specific crops were admitted or banned.
   - Click **"Inspect Raw JSON"** to view the live FastAPI response payload.

---

## 🔍 Real Backend JSON Inspector

Click **"View API JSON"** in the top navigation or open the **"JSON Inspector"** in the sidebar to review live backend network exchanges:
- View live requests and responses for Land Assessments, Recommendations, 9-Stage Plans, Pest Diagnoses, and Harvest Readiness.
- Displays HTTP status, latency in milliseconds, and the exact endpoint URL.
- One-click **"Copy JSON"** to clipboard.
- One-click **"Download .json"** for offline auditing.

---

## 🌿 High-Altitude Candidate Crops Included

1. **Hill Potato** (*Solanum tuberosum*) — ICAR-CPRI Shimla Tech. Bull. 42
2. **Garden Pea** (*Pisum sativum*) — ICAR-VPKAS Almora Mountain Vegetable Guide
3. **Mountain Cabbage** (*Brassica oleracea var. capitata*) — ICAR-IARI Katrain Monograph
4. **Hill Snowball Cauliflower** (*Brassica oleracea var. botrytis*) — ICAR-IARI Katrain
5. **Hill Radish / Mooli** (*Raphanus sativus*) — ICAR-VPKAS Almora
6. **Highland Turnip / Shalgam** (*Brassica rapa subsp. rapa*) — ICAR-IARI Katrain
7. **Cold-Hardy Spinach / Palak** (*Spinacia oleracea*) — GBPUAT Pantnagar / ICAR-IARI
8. **Pahari Rai / Leafy Mustard** (*Brassica juncea*) — ICAR-DRMR Bharatpur & Hill Extension
9. **Mountain Carrot** (*Daucus carota*) — ICAR-IARI Division of Vegetable Science
10. **Highland Broad Bean / Bakla** (*Vicia faba*) — ICAR-RCER / KVK Leh
11. **Highland Hulless Barley (Grim)** (*Hordeum vulgare*) — ICAR-IIWBR Karnal
12. **Tartary Buckwheat (Ogla / Phaphra)** (*Fagopyrum tataricum*) — ICAR-NBPGR Regional Station Shimla

---

## 🛠️ Troubleshooting on Windows

1. **PowerShell Script Execution Policy Error:**
   If running `.ps1` scripts gives an execution policy error, run:
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   ```
   Or simply use the corresponding `.bat` files (`run_backend.bat`, `run_frontend.bat`, `run_all.bat`).

2. **Port 8000 or 5173 Already in Use:**
   - To specify a different backend port:
     ```powershell
     python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8001
     ```
   - Then update `frontend/.env`:
     ```text
     VITE_API_BASE_URL=http://127.0.0.1:8001
     ```

3. **No Laboratory Measurements Prompted:**
   By design, TERRAFORM does not ask for pH, NPK ppm, or electrical conductivity. The system reasons over natural tactile observations (soil ribbon test, drainage time, moisture feel, and stone presence) to infer suitability deterministically.
