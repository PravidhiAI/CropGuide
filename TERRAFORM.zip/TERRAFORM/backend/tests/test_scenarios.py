import pytest
from backend.app.schemas.land_assessment import LandAssessmentInput
from backend.app.engine.land_analysis import land_engine
from backend.app.engine.recommendation import recommendation_engine

def test_scenario_1_cold_sunny_reliable_water():
    """Scenario 1: Cold, sunny terrace with reliable water and crumbly soil."""
    inputs = LandAssessmentInput(
        soil_texture="crumbly_and_balanced",
        drainage="water_drains_gradually",
        soil_moisture="moist_not_waterlogged",
        soil_appearance="dark_brown",
        organic_material="decayed_leaves_compost_visible",
        sunlight="direct_most_of_day",
        climate="cold_days_cold_nights",
        frost="occasional",
        terrace_slope="gentle_slope",
        water_source="reliable_irrigation",
        growing_season="moderate"
    )
    analysis = land_engine.analyze(inputs)
    rec = recommendation_engine.evaluate(inputs)
    
    assert analysis.confidence_level == "high"
    assert len(rec.recommended_crops) >= 5
    top_ids = [c.crop_id for c in rec.recommended_crops[:3]]
    # Major cold terrace crops like potato or pea should be at top
    assert any(c in top_ids for c in ["potato", "garden_pea", "cabbage"])

def test_scenario_2_frequent_frost():
    """Scenario 2: Frequent frost conditions.
    Hard exclusion rule: Buckwheat is frost sensitive (mortality at -0.5C) and MUST be excluded.
    Very hardy crops (Turnip, Spinach, Broad Bean) should be prioritized."""
    inputs = LandAssessmentInput(
        soil_texture="crumbly_and_balanced",
        drainage="water_disappears_quickly",
        soil_moisture="slightly_moist",
        soil_appearance="dark_brown",
        organic_material="some_present",
        sunlight="direct_most_of_day",
        climate="very_cold_conditions",
        frost="frequent",
        terrace_slope="gentle_slope",
        water_source="reliable_irrigation",
        growing_season="moderate"
    )
    rec = recommendation_engine.evaluate(inputs)
    
    # Verify buckwheat is in excluded crops
    excluded_ids = [e.crop_id for e in rec.excluded_crops]
    assert "buckwheat" in excluded_ids
    
    # Check exclusion explanation mentions frost
    bw_ex = next(e for e in rec.excluded_crops if e.crop_id == "buckwheat")
    assert "frost" in bw_ex.primary_exclusion_reason.lower() or "frost" in bw_ex.explanation.lower()

    # Check that hardy crops like spinach, turnip, broad_bean are recommended
    rec_ids = [c.crop_id for c in rec.recommended_crops]
    assert "spinach" in rec_ids or "turnip" in rec_ids

def test_scenario_3_poor_drainage_and_standing_water():
    """Scenario 3: Poor drainage and standing water.
    Hard exclusion rule: Potato, Barley, Carrot cannot tolerate standing water (root hypoxia)."""
    inputs = LandAssessmentInput(
        soil_texture="sticky_and_clay_like",
        drainage="pools_on_surface",
        soil_moisture="very_wet",
        soil_appearance="pale_or_greyish",
        organic_material="some_present",
        sunlight="direct_part_of_day",
        climate="cold_days_cold_nights",
        frost="occasional",
        terrace_slope="nearly_flat",
        water_source="reliable_irrigation",
        growing_season="moderate"
    )
    analysis = land_engine.analyze(inputs)
    rec = recommendation_engine.evaluate(inputs)
    
    # Water stagnation risks flagged
    assert any("rot" in r.lower() or "hypoxia" in r.lower() or "drainage" in r.lower() or "stagnation" in r.lower() for r in analysis.agricultural_risks)
    
    # Barley, Potato, Carrot excluded
    excluded_ids = [e.crop_id for e in rec.excluded_crops]
    assert "potato" in excluded_ids
    assert "barley" in excluded_ids
    assert "carrot" in excluded_ids

def test_scenario_4_limited_sunlight():
    """Scenario 4: Limited sunlight (mostly shaded terrace, e.g. steep mountain shadow).
    Hard exclusion: Barley and Buckwheat require 6+ hours full sun and should be excluded.
    Tolerant greens (Spinach, Turnip) should remain viable."""
    inputs = LandAssessmentInput(
        soil_texture="crumbly_and_balanced",
        drainage="water_drains_gradually",
        soil_moisture="moist_not_waterlogged",
        soil_appearance="dark_brown",
        organic_material="some_present",
        sunlight="mostly_shaded",
        climate="cold_days_cold_nights",
        frost="occasional",
        terrace_slope="gentle_slope",
        water_source="reliable_irrigation",
        growing_season="moderate"
    )
    rec = recommendation_engine.evaluate(inputs)
    excluded_ids = [e.crop_id for e in rec.excluded_crops]
    assert "barley" in excluded_ids or "buckwheat" in excluded_ids
    
    # Spinach should be recommended (high shade tolerance)
    rec_ids = [c.crop_id for c in rec.recommended_crops]
    assert "spinach" in rec_ids

def test_scenario_5_limited_water_no_reliable_source():
    """Scenario 5: Limited water / no reliable source.
    Hard exclusion: High water-demand cole crops (cabbage, cauliflower) are excluded.
    Drought-tolerant crops (barley, buckwheat, leafy mustard) should be recommended."""
    inputs = LandAssessmentInput(
        soil_texture="sandy_and_gritty",
        drainage="water_disappears_quickly",
        soil_moisture="dry_and_dusty",
        soil_appearance="light_brown",
        organic_material="very_little_visible",
        sunlight="direct_most_of_day",
        climate="cold_days_cold_nights",
        frost="rare",
        terrace_slope="gentle_slope",
        water_source="no_reliable_source",
        growing_season="short"
    )
    rec = recommendation_engine.evaluate(inputs)
    excluded_ids = [e.crop_id for e in rec.excluded_crops]
    assert "cabbage" in excluded_ids or "cauliflower" in excluded_ids

def test_scenario_6_short_growing_season():
    """Scenario 6: Short growing season.
    Long season crops (broad bean 110-135d) excluded.
    Fast crops (radish 35-50d, spinach 30-45d, turnip 45-60d) prioritized."""
    inputs = LandAssessmentInput(
        soil_texture="crumbly_and_balanced",
        drainage="water_drains_gradually",
        soil_moisture="slightly_moist",
        soil_appearance="dark_brown",
        organic_material="some_present",
        sunlight="direct_most_of_day",
        climate="cold_days_cold_nights",
        frost="occasional",
        terrace_slope="gentle_slope",
        water_source="reliable_irrigation",
        growing_season="short"
    )
    rec = recommendation_engine.evaluate(inputs)
    excluded_ids = [e.crop_id for e in rec.excluded_crops]
    assert "broad_bean" in excluded_ids
    
    # Fast crops in recommendations
    rec_ids = [c.crop_id for c in rec.recommended_crops]
    assert "radish" in rec_ids
    assert "spinach" in rec_ids

def test_scenario_7_rocky_shallow_terrace():
    """Scenario 7: Rocky or shallow terrace soil.
    Carrots cannot form straight taproots and are hard-excluded."""
    inputs = LandAssessmentInput(
        soil_texture="rocky_or_shallow",
        drainage="water_disappears_quickly",
        soil_moisture="slightly_moist",
        soil_appearance="mixed",
        organic_material="some_present",
        sunlight="direct_most_of_day",
        climate="cold_days_cold_nights",
        frost="occasional",
        terrace_slope="uneven_or_rocky",
        water_source="reliable_irrigation",
        growing_season="moderate"
    )
    rec = recommendation_engine.evaluate(inputs)
    excluded_ids = [e.crop_id for e in rec.excluded_crops]
    assert "carrot" in excluded_ids
    ex_carrot = next(e for e in rec.excluded_crops if e.crop_id == "carrot")
    assert "rock" in ex_carrot.explanation.lower() or "taproot" in ex_carrot.explanation.lower()
