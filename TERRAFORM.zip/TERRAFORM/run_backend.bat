@echo off
title TERRAFORM - FastAPI Backend Server
cd /d "%~dp0"
echo ==========================================================
echo  TERRAFORM -- Starting FastAPI Backend Server
echo  Scenario: High-Altitude Cold Terrace Decision Support
echo ==========================================================

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Python is not installed or not in PATH.
    pause
    exit /b 1
)

echo Checking dependencies...
python -m pip install -r backend/requirements.txt --quiet

echo Starting Uvicorn server on http://127.0.0.1:8000 ...
echo API Docs: http://127.0.0.1:8000/docs
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
pause
